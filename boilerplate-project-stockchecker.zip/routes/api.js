const { ObjectId } = require('mongodb');

module.exports = function(app, db) {

  // Create a new book
  app.post('/api/books', (req, res) => {
    const { title, author, isbn } = req.body;
    if (!title || !author || !isbn) {
      return res.status(400).send('Missing required fields');
    }
    const book = { title, author, isbn };
    db.collection('books').insertOne(book, (err, result) => {
      if (err) {
        return res.status(500).send('Error creating book');
      }
      res.status(201).json(result.ops[0]);
    });
  });

  // Get all books
  app.get('/api/books', (req, res) => {
    db.collection('books').find({}).toArray((err, books) => {
      if (err) {
        return res.status(500).send('Error getting books');
      }
      res.json(books);
    });
  });

  // Get a book by ID
  app.get('/api/books/:id', (req, res) => {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).send('Invalid book ID');
    }
    db.collection('books').findOne({ _id: ObjectId(id) }, (err, book) => {
      if (err) {
        return res.status(500).send('Error getting book');
      }
      if (!book) {
        return res.status(404).send('Book not found');
      }
      res.json(book);
    });
  });

  // Update a book by ID
  app.put('/api/books/:id', (req, res) => {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).send('Invalid book ID');
    }
    const { title, author, isbn } = req.body;
    if (!title && !author && !isbn) {
      return res.status(400).send('No update fields provided');
    }
    const update = {};
    if (title) {
      update.title = title;
    }
    if (author) {
      update.author = author;
    }
    if (isbn) {
      update.isbn = isbn;
    }
    db.collection('books').findOneAndUpdate({ _id: ObjectId(id) }, { $set: update }, { returnOriginal: false }, (err, result) => {
      if (err) {
        return res.status(500).send('Error updating book');
      }
      if (!result.value) {
        return res.status(404).send('Book not found');
      }
      res.json(result.value);
    });
  });

  // Delete a book by ID
  app.delete('/api/books/:id', (req, res) => {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).send('Invalid book ID');
    }
    db.collection('books').deleteOne({ _id: ObjectId(id) }, (err, result) => {
      if (err) {
        return res.status(500).send('Error deleting book');
      }
      if (result.deletedCount === 0) {
        return res.status(404).send('Book not found');
      }
      res.sendStatus(204);
    });
  });

};
