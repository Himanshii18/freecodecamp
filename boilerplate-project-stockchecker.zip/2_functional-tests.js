const chai = require("chai");
const assert = chai.assert;
const server = require("../server");
const chaiHttp = require("chai-http");

chai.use(chaiHttp);

describe("Functional Tests", function() {
  describe("GET /api/convert", function() {
    it("Converts a valid input with a valid unit", function(done) {
      chai
        .request(server)
        .get("/api/convert?input=10gal")
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.equal(res.body.initNum, 10);
          assert.equal(res.body.initUnit, "gal");
          assert.approximately(res.body.returnNum, 37.8541, 0.1);
          assert.equal(res.body.returnUnit, "L");
          assert.equal(res.body.string, "10 gallons converts to 37.8541 liters");
          done();
        });
    });

    it("Converts a valid input with an invalid unit", function(done) {
      chai
        .request(server)
        .get("/api/convert?input=10gals")
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.equal(res.body.initNum, null);
          assert.equal(res.body.initUnit, null);
          assert.equal(res.body.returnNum, null);
          assert.equal(res.body.returnUnit, null);
          assert.equal(res.body.string, "invalid unit");
          done();
        });
    });

    it("Converts an invalid input", function(done) {
      chai
        .request(server)
        .get("/api/convert?input=abc")
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.equal(res.body.initNum, null);
          assert.equal(res.body.initUnit, null);
          assert.equal(res.body.returnNum, null);
          assert.equal(res.body.returnUnit, null);
          assert.equal(res.body.string, "invalid number and unit");
          done();
        });
    });

    it("Converts with no number input", function(done) {
      chai
        .request(server)
        .get("/api/convert?input=gal")
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.equal(res.body.initNum, 1);
          assert.equal(res.body.initUnit, "gal");
          assert.approximately(res.body.returnNum, 3.78541, 0.1);
          assert.equal(res.body.returnUnit, "L");
          assert.equal(res.body.string, "1 gallon converts to 3.78541 liters");
          done();
        });
    });
  });
});
test('Viewing one stock', (done) => {
  chai.request(server)
    .get('/api/stock-prices')
    .query({ stock: 'AAPL' })
    .end((err, res) => {
      assert.equal(res.status, 200);
      assert.property(res.body, 'stockData');
      assert.property(res.body.stockData, 'stock');
      assert.property(res.body.stockData, 'price');
      assert.property(res.body.stockData, 'likes');
      assert.equal(res.body.stockData.stock, 'AAPL');
      done();
    });
});
test('Viewing one stock and liking it', (done) => {
  chai.request(server)
    .get('/api/stock-prices')
    .query({ stock: 'AAPL', like: true })
    .end((err, res) => {
      assert.equal(res.status, 200);
      assert.property(res.body, 'stockData');
      assert.property(res.body.stockData, 'stock');
      assert.property(res.body.stockData, 'price');
      assert.property(res.body.stockData, 'likes');
      assert.equal(res.body.stockData.stock, 'AAPL');
      assert.equal(res.body.stockData.likes, 1);
      done();
    });
});
test('Viewing the same stock and liking it again', (done) => {
  chai.request(server)
    .get('/api/stock-prices')
    .query({ stock: 'AAPL', like: true })
    .end((err, res) => {
      assert.equal(res.status, 200);
      assert.property(res.body, 'stockData');
      assert.property(res.body.stockData, 'stock');
      assert.property(res.body.stockData, 'price');
      assert.property(res.body.stockData, 'likes');
      assert.equal(res.body.stockData.stock, 'AAPL');
      assert.equal(res.body.stockData.likes, 1);
      done();
    });
});
test('Viewing two stocks', (done) => {
  chai.request(server)
    .get('/api/stock-prices')
    .query({ stock: ['AAPL', 'GOOG'] })
    .end((err, res) => {
      assert.equal(res.status, 200);
      assert.property(res.body, 'stockData');
      assert.isArray(res.body.stock
